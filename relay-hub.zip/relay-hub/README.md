# Relay Hub

**A self-hosted web proxy with a launcher-style home screen.**
Night-sky hub with a search bar, pinned sites and app grid — plus a full-screen browser view
that fetches pages on the server and rewrites them so links, images, styles and forms all work
through the proxy.

Zero dependencies. Node.js 18+.

![Relay Hub home screen](docs/screenshot-hub.png)

---

## Features

**Hub**
- Cinematic home screen: blurred night backdrop, live clock, exit-node badge
- Search bar that takes a URL *or* plain words (Bing / DuckDuckGo / Google, switchable)
- "Jump back in" — recent sites, stored locally in your browser only
- Quick-launch tiles, an app drawer (`Apps`) and a settings sheet
- Keyboard first: `/` to search, `Esc` to close panels

**Browser view** (`/browse`)
- Full-bleed proxied rendering inside the hub chrome
- Address bar, back / forward / reload / hub buttons
- **Full** mode (site JavaScript on) and **Reader** mode (scripts stripped for clean reading)
- "Copy link" produces a shareable `/fetch?url=…` URL
- Address bar follows in-page navigation; Alt+← / Alt+→ to go back and forward

**Proxy engine**
- Rewrites `href`, `src`, `srcset`, `poster`, `action`, `data-src`, inline `style`, `<style>` blocks,
  external CSS `url()` / `@import`, and `<meta refresh>`
- Server-side cookie jar per target site, so logins and sessions behave normally
- Resolves relative `fetch()`/XHR calls via `Referer`, then a `relay_base` cookie
- GET and POST forms relayed with bodies intact
- Strips upstream CSP headers/meta tags and SRI hashes (they'd block proxied assets)
- Charset detection → re-encoded as UTF-8
- Unwraps click-tracking redirects (e.g. Bing `/ck/a?…`)
- Blocks private/loopback/link-local targets (no SSRF), 25 s upstream timeout

![Browsing Wikipedia through the proxy](docs/screenshot-browse.png)

<p align="center"><img src="docs/screenshot-apps.png" alt="App drawer" width="640"></p>

---

## Push this repo to GitHub

The project is already committed on `main`. To publish it:

```bash
# with the GitHub CLI (easiest)
gh repo create relay-hub --public --source=. --remote=origin --push

# or with a repo you created on github.com
git remote add origin https://github.com/<you>/relay-hub.git
git push -u origin main
```

Then, **Pick your host**:

- **Render** — Dashboard → New → *Blueprint* → pick the repo → it reads `render.yaml`.
  Set `RELAY_PASS` in the dashboard when prompted (leave blank to run open).
- **Fly.io** — `fly launch --copy-config --now` (reads `fly.toml`), then
  `fly secrets set RELAY_PASS=something-long RELAY_REPO_URL=https://github.com/<you>/relay-hub`.
- **Railway / VPS** — the repo has `railway.json`, a `Dockerfile`, `docker-compose.yml` and a `Procfile`.

Every host above gives you HTTPS automatically.

---

## Quick start

```bash
git clone https://github.com/<you>/relay-hub.git
cd relay-hub
node server.js
# → http://localhost:3000
```

No `npm install` — there are no dependencies.

### Docker

```bash
docker build -t relay-hub .
docker run -p 3000:3000 relay-hub
```

### Deploy

| Host | How |
| --- | --- |
| **Fly.io** | `fly launch --copy-config --now` (uses `fly.toml`) |
| **Render** | New → Blueprint → point at the repo (uses `render.yaml`) |
| **Railway** | New project → Deploy from repo (uses `railway.json`) |
| **Any VPS** | `docker compose up -d` (uses `docker-compose.yml`) |

---

## Configuration

All optional, set as environment variables:

| Variable | Default | What it does |
| --- | --- | --- |
| `PORT` | `3000` | Port to listen on (binds `0.0.0.0`) |
| `RELAY_USER` | `relay` | Username when auth is enabled |
| `RELAY_PASS` | *(empty)* | **Set this to require HTTP basic auth.** Empty = open |
| `RELAY_REPO_URL` | *(empty)* | Shows a GitHub button in the hub linking to this repo |
| `RELAY_LOG` | on | `0` silences per-request logs |

```bash
RELAY_PASS='something-long' RELAY_REPO_URL='https://github.com/you/relay-hub' node server.js
```

> **Deploying publicly?** Set `RELAY_PASS`, and put TLS in front (Fly/Render/Railway do this for you,
> or use Caddy/Cloudflare Tunnel on a VPS).

---

## Endpoints

```
GET  /                        hub (launcher)
GET  /browse?url=<url>[&m=1]  browser view (m=1 → Reader mode)
GET  /fetch?url=<url>[&m=1]   proxied + rewritten page (works standalone, e.g. in a new tab)
GET  /raw?url=<url>           proxied stream, no rewriting (images, files, media)
ANY  /form/<base64url(url)>   form submissions
GET  /api/ip                  exit node: IP, city, country, latency, request count
GET  /api/config              repo URL / auth flags for the UI
GET  /assets/*                theme, wallpaper, icons
```

`/fetch?url=…` is a normal link — you can bookmark it or send it to someone.

---

## Known limits

These are inherent to any HTML-rewriting proxy, not bugs:

- **Sites that fingerprint or block datacenter IPs** (Google, YouTube, banks, some Cloudflare sites)
  will show captchas or refuse to load. Expect captchas on all major search engines except Bing;
  DuckDuckGo and Google usually refuse outright from cloud hosting. Wikipedia, news sites, docs, Hacker News, Gutenberg and
  Bing all work.
- **JavaScript challenges** (Cloudflare "checking your browser") can't complete in Reader mode.
- **SPA-heavy sites** that build URLs entirely client-side can produce paths the proxy can't resolve.
- Because proxied pages are served from the proxy's origin, a hostile page could in principle read
  proxy cookies. Don't log into sensitive accounts through a public instance you don't control.

---

## Security notes

- Private, loopback, link-local and cloud-metadata addresses are refused (`169.254.169.254`, `10/8`,
  `172.16/12`, `192.168/16`, `127/8`, `::1`, `.local`, `.internal`).
- Optional basic auth via `RELAY_PASS`; TLS is expected to be terminated by the host/proxy in front.
- The proxy will happily fetch anything public on the internet — that is its job. Run it for people
  you trust, behind auth, and watch your egress bill.

## License

MIT — see [LICENSE](LICENSE).
