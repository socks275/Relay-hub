#!/usr/bin/env node
'use strict';

/*
 * Relay — a server-side web proxy.
 * Fetches pages from this machine (cloud egress) and relays them to the browser,
 * rewriting links, subresources, CSS and forms so everything flows through here.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const { Readable } = require('stream');

const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const AUTH_USER = process.env.RELAY_USER || 'relay';
const AUTH_PASS = process.env.RELAY_PASS || ''; // set to enable basic auth
const REPO_URL = process.env.RELAY_REPO_URL || '';

const MAX_TEXT = 12 * 1024 * 1024; // max HTML/CSS we buffer & rewrite
const MAX_BODY = 10 * 1024 * 1024; // max request body we forward
const TIMEOUT = 25000;

/* ------------------------------------------------------------------ */
/*  UI + assets                                                        */
/* ------------------------------------------------------------------ */

const PUBLIC_DIR = path.join(__dirname, 'public');

const PAGE_FILES = {
  '/': 'hub.html',
  '/hub': 'hub.html',
  '/browse': 'browse.html',
};

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
};

const pageCache = new Map();

function readPage(file) {
  const full = path.join(PUBLIC_DIR, file);
  const st = fs.statSync(full);
  const hit = pageCache.get(file);
  if (hit && hit.mtime === st.mtimeMs) return hit.buf;
  const buf = fs.readFileSync(full);
  pageCache.set(file, { buf, mtime: st.mtimeMs });
  return buf;
}

function servePage(res, file) {
  let buf;
  try {
    buf = readPage(file);
  } catch (e) {
    res.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' });
    return res.end('UI file missing: ' + file);
  }
  res.writeHead(200, {
    'content-type': 'text/html; charset=utf-8',
    'cache-control': 'no-cache',
    'x-content-type-options': 'nosniff',
  });
  res.end(buf);
}

function serveAsset(res, relPath) {
  // /assets/theme.css → public/theme.css
  const inner = relPath.replace(/^\/assets/, '') || '/';
  const target = path.resolve(PUBLIC_DIR, '.' + inner);
  if (!target.startsWith(PUBLIC_DIR + path.sep)) {
    res.writeHead(403, { 'content-type': 'text/plain' });
    return res.end('Forbidden');
  }
  fs.stat(target, (err, st) => {
    if (err || !st.isFile()) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      return res.end('Not found');
    }
    const ext = path.extname(target).toLowerCase();
    const cache = /\.(jpg|jpeg|png|webp|svg|woff2|ico)$/.test(ext) ? 'public, max-age=604800' : 'no-cache';
    res.writeHead(200, { 'content-type': MIME[ext] || 'application/octet-stream', 'cache-control': cache });
    fs.createReadStream(target).pipe(res);
  });
}

const FAVICON = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
<stop offset="0" stop-color="#34d399"/><stop offset="1" stop-color="#22d3ee"/>
</linearGradient></defs>
<rect width="64" height="64" rx="16" fill="url(#g)"/>
<path d="M16 40c0-12 9.5-21 21-21 7 0 12.6 3.2 16 8.2" fill="none" stroke="#06231b" stroke-width="5" stroke-linecap="round"/>
<path d="M48 24c0 12-9.5 21-21 21-7 0-12.6-3.2-16-8.2" fill="none" stroke="#06231b" stroke-width="5" stroke-linecap="round"/>
<circle cx="48" cy="34" r="4.5" fill="#06231b"/><circle cx="16" cy="30" r="4.5" fill="#06231b"/>
</svg>`;

/* ------------------------------------------------------------------ */
/*  Cookie jar (server-side, keyed by target origin)                   */
/* ------------------------------------------------------------------ */

const jar = new Map();

function cookiesFor(origin) {
  const m = jar.get(origin);
  if (!m || !m.size) return '';
  return [...m].map(([k, v]) => `${k}=${v}`).join('; ');
}

function rememberCookies(origin, setCookies) {
  if (!setCookies || !setCookies.length) return;
  let m = jar.get(origin);
  if (!m) {
    m = new Map();
    jar.set(origin, m);
  }
  for (const sc of setCookies) {
    const first = String(sc).split(';')[0];
    const eq = first.indexOf('=');
    if (eq <= 0) continue;
    const name = first.slice(0, eq).trim();
    const value = first.slice(eq + 1).trim();
    if (!name) continue;
    if (/max-age=0(;|$)/i.test(sc) || /expires=thu, 01 jan 1970/i.test(sc)) m.delete(name);
    else m.set(name, value);
  }
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

let requestsServed = 0;

// A per-browser nonce lets only *our* injected helper drive the proxy UI.
// It lives in an HttpOnly cookie so proxied page scripts can't read or forge it.
function checkAuth(req, res) {
  if (!AUTH_PASS) return true;
  const header = req.headers.authorization || '';
  const m = /^Basic\s+(.+)$/i.exec(header);
  if (m) {
    let decoded = '';
    try { decoded = Buffer.from(m[1], 'base64').toString('utf8'); } catch { decoded = ''; }
    const idx = decoded.indexOf(':');
    const user = idx >= 0 ? decoded.slice(0, idx) : '';
    const pass = idx >= 0 ? decoded.slice(idx + 1) : '';
    if (user === AUTH_USER && pass === AUTH_PASS) return true;
  }
  res.writeHead(401, {
    'www-authenticate': 'Basic realm="Relay", charset="UTF-8"',
    'content-type': 'text/plain; charset=utf-8',
  });
  res.end('Relay — authentication required');
  return false;
}

function sessionNonce(req) {
  const m = /(?:^|;\s*)relay_n=([a-f0-9]+)/.exec(req.headers.cookie || '');
  if (m) return m[1];
  return require('crypto').randomBytes(16).toString('hex');
}
function nonceSetCookie(nonce) {
  return 'relay_n=' + nonce + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800';
}

function b64url(str) {
  return Buffer.from(str, 'utf8').toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function unb64url(str) {
  return Buffer.from(str.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
}

function decodeEntities(s) {
  return String(s)
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#0*39;|&apos;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>');
}

function escapeAttr(s) {
  return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function isPrivateHost(hostname) {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal')) return true;
  if (h === '0.0.0.0' || h === '::1' || h === '::') return true;
  if (h === '169.254.169.254' || h === 'metadata.google.internal') return true;
  const m = h.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (m) {
    const a = +m[1], b = +m[2];
    if (a === 10 || a === 127 || a === 0) return true;
    if (a === 192 && b === 168) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 169 && b === 254) return true;
  }
  return false;
}

function checkTarget(raw, req) {
  let u;
  try {
    u = new URL(raw);
  } catch {
    throw new Error('That doesn’t look like a valid URL.');
  }
  if (!/^https?:$/.test(u.protocol)) throw new Error('Only http:// and https:// URLs can be proxied.');
  if (isPrivateHost(u.hostname)) throw new Error('Local and private network addresses are blocked.');
  const selfHost = (req.headers.host || '').split(':')[0].toLowerCase();
  if (selfHost && u.hostname.toLowerCase() === selfHost) throw new Error('A proxy can’t proxy itself (loop blocked).');
  return u.href;
}

function detectCharset(ct, buf) {
  let m = /charset\s*=\s*["']?([\w-]+)/i.exec(ct || '');
  if (m) return m[1].toLowerCase();
  if (buf && buf.length) {
    const head = buf.slice(0, 4096).toString('latin1');
    m = /<meta[^>]+charset\s*=\s*["']?([\w-]+)/i.exec(head);
    if (m) return m[1].toLowerCase();
  }
  return 'utf-8';
}

function decodeBuffer(buf, charset) {
  try {
    return new TextDecoder(charset, { fatal: false }).decode(buf);
  } catch {
    return new TextDecoder('utf-8', { fatal: false }).decode(buf);
  }
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new Error('Request body too large.'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function friendlyError(err) {
  if (!err) return 'Something went wrong.\nPlease try again.';
  if (err.name === 'AbortError' || err.name === 'TimeoutError') {
    return 'The site took too long to respond.\nRelay gives up after 25 seconds — the site may be down or blocking proxies.';
  }
  const cause = err.cause && (err.cause.message || err.cause.code);
  const msg = String(err.message || err) + ' ' + String(cause || '');
  if (/ENOTFOUND|EAI_AGAIN|getaddrinfo/i.test(msg)) {
    return 'Couldn’t find that domain.\nThe address may be misspelled, or the site no longer exists.';
  }
  if (/CERT|SSL|TLS|EPROTO|self.signed/i.test(msg)) {
    return 'Secure connection failed.\nThe site’s TLS certificate could not be verified.';
  }
  if (/ECONNREFUSED/i.test(msg)) return 'The site refused the connection.\nIt may be down, or firewalled against proxies.';
  if (/ECONNRESET/i.test(msg)) return 'The connection was reset by the site.\nThis often means the site is blocking automated access.';
  if (/redirect/i.test(msg)) return 'The site redirected too many times.\nIts redirect loop was stopped by the proxy.';
  return String(err.message || err).replace(/^fetch failed$/i, 'Couldn’t reach that site.\nThe request failed before any response came back.');
}

/* ------------------------------------------------------------------ */
/*  URL mapping / rewriting                                            */
/* ------------------------------------------------------------------ */

const SKIP_SCHEME = /^(?:#|javascript:|mailto:|tel:|sms:|data:|blob:|about:|chrome:|magnet:|whatsapp:|intent:|market:)/i;

function mapUrl(rawInput, base, opts = {}) {
  if (rawInput === undefined || rawInput === null) return rawInput;
  const raw = String(rawInput).trim();
  if (!raw) return rawInput;
  if (SKIP_SCHEME.test(raw)) return rawInput;

  let candidate = raw;

  // Already proxied? Unwrap so we never double-proxy.
  const proxied = /(?:^|\/)(?:fetch|raw)\?url=([^&#]+)/.exec(candidate);
  if (proxied) {
    try { candidate = decodeURIComponent(proxied[1]); } catch { return rawInput; }
  }

  let abs;
  try {
    abs = new URL(candidate, base);
  } catch {
    return rawInput;
  }
  if (!/^https?:$/.test(abs.protocol)) return rawInput;

  // Unwrap Bing's click-tracking redirects (…/ck/a?…&u=a1<base64url>) so links
  // in results point straight at the real destination.
  if (/(^|\.)bing\.com$/i.test(abs.hostname) && /\/ck\/a\b/.test(abs.pathname)) {
    const u = abs.searchParams.get('u');
    if (u && /^a1/.test(u)) {
      try {
        const decoded = Buffer.from(u.slice(2).replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
        if (/^https?:\/\//.test(decoded)) abs = new URL(decoded);
      } catch { /* keep original */ }
    }
  }

  if (opts.form) return '/form/' + b64url(abs.href);
  return '/fetch?url=' + encodeURIComponent(abs.href) + (opts.reader ? '&m=1' : '');
}

function mapCssUrl(raw, base, quoted) {
  // Handle #fragment / data: / about: untouched
  if (!raw || SKIP_SCHEME.test(raw.trim())) return null;
  const mapped = mapUrl(raw.trim(), base);
  if (!quoted) {
    // Unquoted url() in an inline style attribute: avoid parens/quotes/spaces.
    return mapped.replace(/\(/g, '%28').replace(/\)/g, '%29').replace(/\s/g, '%20').replace(/"/g, '%22').replace(/'/g, '%27');
  }
  return mapped.replace(/"/g, '%22');
}

function rewriteCssUrls(css, base, quoted) {
  let out = String(css).replace(/url\(\s*(?:"([^"]*)"|'([^']*)'|([^'")]*?))\s*\)/gi, (m, dq, sq, uq) => {
    const raw = dq !== undefined ? dq : sq !== undefined ? sq : uq;
    if (raw === undefined) return m;
    const mapped = mapCssUrl(raw, base, quoted);
    return mapped === null ? m : `url(${quoted ? '"' : ''}${mapped}${quoted ? '"' : ''})`;
  });
  out = out.replace(/@import\s+(?:"([^"]*)"|'([^']*)')/gi, (m, dq, sq) => {
    const raw = dq !== undefined ? dq : sq;
    const mapped = mapUrl(raw, base);
    return `@import url("${mapped.replace(/"/g, '%22')}")`;
  });
  return out;
}

function rewriteStyleTag(block, base) {
  // block is <style ...>...</style>
  const m = /^(<style\b[^>]*>)([\s\S]*?)(<\/style\s*>)$/i.exec(block);
  if (!m) return block;
  return m[1] + rewriteCssUrls(m[2], base, true) + m[3];
}

function splitBlocks(html) {
  const parts = [];
  const re = /<(script|style|textarea|title)\b[^>]*>[\s\S]*?<\/\1\s*>/gi;
  let last = 0;
  let m;
  while ((m = re.exec(html))) {
    if (m.index > last) parts.push({ raw: false, text: html.slice(last, m.index) });
    parts.push({ raw: true, tag: m[1].toLowerCase(), text: m[0] });
    last = re.lastIndex;
  }
  if (last < html.length) parts.push({ raw: false, text: html.slice(last) });
  return parts;
}

function helperScript(target, nonce) {
  const t = JSON.stringify(target);
  const n = JSON.stringify(nonce || '');
  return `<script>(function(){var T=${t},N=${n};function p(m){try{parent.postMessage(m,"*")}catch(e){}}function nav(){p({__relay:1,type:"nav",nonce:N,target:T,proxy:location.href,title:document.title||""})}if(document.readyState==="complete")nav();else window.addEventListener("load",nav);setTimeout(nav,400);setTimeout(nav,1500);window.addEventListener("message",function(e){var d=e.data||{};if(!d.__relayCmd)return;try{if(d.cmd==="back")history.back();else if(d.cmd==="forward")history.forward();else if(d.cmd==="reload")location.reload()}catch(x){}})})();</script>`;
}

function rewriteRefresh(content, base) {
  return String(content).replace(/(url\s*=\s*['"]?)([^'";]+)/gi, (m, pre, u) => pre + mapUrl(u, base));
}

function rewriteHtml(html, finalUrl, reader, nonce) {
  let eff = finalUrl;
  const baseTag = /<base\b[^>]*href\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(html);
  if (baseTag) {
    const cand = baseTag[1] !== undefined ? baseTag[1] : baseTag[2] !== undefined ? baseTag[2] : baseTag[3];
    try { eff = new URL(decodeEntities(cand), finalUrl).href; } catch { /* keep finalUrl */ }
  }

  html = html.replace(/<base\b[^>]*>/gi, '');
  html = html.replace(/<meta\b[^>]*http-equiv\s*=\s*["']?\s*content-security-policy["']?[^>]*>/gi, '');
  html = html.replace(/<meta\b[^>]*name\s*=\s*["']?\s*referrer["']?[^>]*>/gi, '');
  html = html.replace(/\sintegrity\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, '');
  if (reader) html = html.replace(/<meta\b[^>]*http-equiv\s*=\s*["']?\s*refresh["']?[^>]*>/gi, '');
  // Keep link clicks inside the proxy viewer instead of spawning new tabs.
  html = html.replace(/\starget\s*=\s*(?:"_blank"|'_blank'|_blank|"_new"|'_new')/gi, '');

  const parts = splitBlocks(html);
  const outParts = parts.map((part) => {
    if (part.raw) {
      if (part.tag === 'script') return reader ? '' : part.text;
      if (part.tag === 'style') return rewriteStyleTag(part.text, eff);
      return part.text;
    }
    let s = part.text;

    // meta refresh redirects
    s = s.replace(
      /(<meta\b[^>]*http-equiv\s*=\s*["']?\s*refresh["']?[^>]*content\s*=\s*["'])([^"']*)(["'])/gi,
      (m, a, c, b) => a + rewriteRefresh(decodeEntities(c), eff) + b
    );

    // URLs in attributes.  Note the capture groups: `all` is the quoted token,
    // dq/sq/uq are the *inner* values — we must map the inner value, never `all`.
    s = s.replace(
      /(\s(?:href|src|action|poster|data-src|data-href|data-bg)\s*=\s*)("([^"]*)"|'([^']*)'|([^\s>]+))/gi,
      (m, pre, all, dq, sq, uq) => {
        const raw = dq !== undefined ? dq : sq !== undefined ? sq : uq;
        const value = decodeEntities(raw);
        const isAction = /action\s*=\s*$/i.test(pre);
        let mapped;
        if (isAction) {
          mapped = value.trim() === '' ? '/form/' + b64url(eff) : mapUrl(value, eff, { form: true });
        } else {
          mapped = mapUrl(value, eff, { reader });
        }
        return pre + '"' + escapeAttr(mapped) + '"';
      }
    );

    // srcset
    s = s.replace(/(\ssrcset\s*=\s*)("([^"]*)"|'([^']*)')/gi, (m, pre, all, dq, sq) => {
      const raw = decodeEntities(dq !== undefined ? dq : sq);
      const mapped = String(raw)
        .split(',')
        .map((candidate) => {
          const t = candidate.trim();
          if (!t) return '';
          const bits = t.split(/\s+/);
          const u = bits.shift();
          return [mapUrl(u, eff, { reader }), ...bits].join(' ');
        })
        .filter(Boolean)
        .join(', ');
      return pre + '"' + escapeAttr(mapped) + '"';
    });

    // inline style="..."
    s = s.replace(/style\s*=\s*("([^"]*)"|'([^']*)')/gi, (m, all, dq, sq) => {
      const raw = decodeEntities(dq !== undefined ? dq : sq);
      const quote = dq !== undefined ? '"' : "'";
      return 'style=' + quote + rewriteCssUrls(raw, eff, false) + quote;
    });

    // strip duplicate event handlers in reader mode
    if (reader) s = s.replace(/\son[a-z]+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');

    return s;
  });

  let out = outParts.join('');

  // Referrer is needed for subresource fallback resolution.
  const headInject = `<meta name="referrer" content="unsafe-url">` + `<meta name="relay-target" content="${escapeAttr(finalUrl)}">`;
  out = /<\/head\s*>/i.test(out) ? out.replace(/<\/head\s*>/i, headInject + '</head>') : headInject + out;

  // Our tiny helper is always injected (even in Reader mode, which strips page scripts)
  // so the proxy UI can track in-frame navigation and drive back/forward.
  const tail = helperScript(finalUrl, nonce);
  out = /<\/body\s*>/i.test(out) ? out.replace(/<\/body\s*>/i, tail + '</body>') : out + tail;
  return out;
}

/* ------------------------------------------------------------------ */
/*  Error page                                                         */
/* ------------------------------------------------------------------ */

function errorPage(res, status, target, message, extra = '') {
  const safeTarget = escapeHtml(target || '');
  const readerHref = target ? `/fetch?url=${encodeURIComponent(target)}&m=1` : '/';
  const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Relay — couldn’t load page</title>
<style>
:root{color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:radial-gradient(900px 500px at 20% -10%,rgba(34,211,238,.12),transparent 60%),radial-gradient(700px 400px at 90% 0%,rgba(129,140,248,.12),transparent 55%),#06090e;color:#e8eef7;font:15px/1.6 ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;padding:24px}
.card{max-width:560px;width:100%;background:rgba(13,20,30,.8);border:1px solid rgba(148,163,184,.18);border-radius:18px;padding:30px;box-shadow:0 30px 80px -30px rgba(0,0,0,.8)}
.badge{display:inline-flex;align-items:center;gap:8px;font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:#fca5a5;font-weight:600;margin-bottom:14px}
.dot{width:7px;height:7px;border-radius:99px;background:#f87171;box-shadow:0 0 12px #f87171}
h1{font-size:23px;line-height:1.25;letter-spacing:-.02em;margin:0 0 8px;font-weight:650}
p{margin:0 0 18px;color:#93a3b8;font-size:14px}
.url{font:12.5px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace;background:rgba(6,9,14,.7);border:1px solid rgba(148,163,184,.14);border-radius:10px;padding:10px 12px;color:#a7b4c6;word-break:break-all;margin-bottom:22px}
.row{display:flex;gap:10px;flex-wrap:wrap}
a.btn{display:inline-flex;align-items:center;gap:7px;text-decoration:none;font-weight:600;font-size:13px;padding:9px 15px;border-radius:10px;border:1px solid rgba(148,163,184,.2);color:#e8eef7}
a.primary{background:linear-gradient(135deg,#34d399,#22d3ee);color:#04110c;border:0}
small{color:#6b7a8f;font-size:11.5px}
</style></head><body><div class="card">
<div class="badge"><span class="dot"></span>Relay · request failed${status ? ` · ${status}` : ''}</div>
<h1>${escapeHtml(message.split('\n')[0] || 'Couldn’t load this page.')}</h1>
<p>${escapeHtml((message.split('\n')[1] || 'The site may block proxies, be offline, or take too long to answer.'))}</p>
${safeTarget ? `<div class="url">${safeTarget}</div>` : ''}
<div class="row"><a class="btn primary" href="${readerHref}">Try Reader mode</a><a class="btn" href="/">← Relay home</a></div>
${extra ? `<p style="margin-top:18px"><small>${extra}</small></p>` : ''}
</div></body></html>`;
  res.writeHead(status || 502, {
    'content-type': 'text/html; charset=utf-8',
    'cache-control': 'no-store',
    'access-control-allow-origin': '*',
  });
  res.end(html);
}

/* ------------------------------------------------------------------ */
/*  Core proxy                                                         */
/* ------------------------------------------------------------------ */

async function proxyRequest(req, res, target, opts = {}) {
  const started = Date.now();
  let body = null;
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    try {
      body = await readBody(req, MAX_BODY);
    } catch (e) {
      return errorPage(res, 413, target, 'Request body was too large to relay.');
    }
  }

  const headers = {
    'user-agent': UA,
    accept: req.headers.accept || '*/*',
    'accept-language': req.headers['accept-language'] || 'en-GB,en;q=0.9,en-US;q=0.8',
  };
  if (req.headers['content-type']) headers['content-type'] = req.headers['content-type'];
  if (req.headers.range) headers.range = req.headers.range;
  const ck = cookiesFor(new URL(target).origin);
  if (ck) headers.cookie = ck;

  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), TIMEOUT);
  let upstream;
  try {
    upstream = await fetch(target, {
      method: req.method,
      headers,
      body: body && body.length ? body : undefined,
      redirect: 'follow',
      signal: ac.signal,
    });
  } catch (err) {
    clearTimeout(timer);
    console.log(`${req.method} ${target} -> ERROR ${err.message}`);
    return errorPage(res, 502, target, friendlyError(err));
  }
  clearTimeout(timer);

  requestsServed++;
  try {
    if (upstream.headers.getSetCookie) rememberCookies(new URL(target).origin, upstream.headers.getSetCookie());
  } catch { /* ignore */ }

  const ct = upstream.headers.get('content-type') || '';
  const common = {
    'access-control-allow-origin': '*',
    'cache-control': upstream.headers.get('cache-control') || 'no-cache',
  };
  const contentRange = upstream.headers.get('content-range');
  if (contentRange) common['content-range'] = contentRange;
  const acceptRanges = upstream.headers.get('accept-ranges');
  if (acceptRanges) common['accept-ranges'] = acceptRanges;

  const isHtml = /(?:text\/html|application\/xhtml\+xml)/i.test(ct);
  const isCss = /text\/css/i.test(ct);
  const status = upstream.status === 304 ? 200 : upstream.status;

  if (req.method === 'HEAD' || status === 204 || status === 205) {
    res.writeHead(status, { ...common, 'content-type': ct || 'application/octet-stream' });
    return res.end();
  }

  // HTML: buffer, decode, rewrite
  if (isHtml && !opts.forceStream) {
    const declared = Number(upstream.headers.get('content-length') || 0);
    if (!declared || declared <= MAX_TEXT) {
      const buf = Buffer.from(await upstream.arrayBuffer());
      if (buf.length <= MAX_TEXT) {
        const charset = detectCharset(ct, buf);
        let html = decodeBuffer(buf, charset);
        html = rewriteHtml(html, upstream.url || target, !!opts.reader, opts.nonce);
        res.writeHead(status, {
          ...common,
          'content-type': 'text/html; charset=utf-8',
          'set-cookie': 'relay_base=' + b64url(upstream.url || target) + '; Path=/; SameSite=Lax; Max-Age=86400',
        });
        res.end(html);
        if (process.env.RELAY_LOG !== '0') {
          console.log(`${req.method} ${target} -> ${status} html ${buf.length}b ${Date.now() - started}ms${opts.reader ? ' [reader]' : ''}`);
        }
        return;
      }
      // too big after download: fall through to raw output of the buffer
      res.writeHead(status, { ...common, 'content-type': ct || 'text/html; charset=utf-8' });
      res.end(buf);
      return;
    }
  }

  // CSS: rewrite url() references
  if (isCss) {
    const buf = Buffer.from(await upstream.arrayBuffer());
    const css = decodeBuffer(buf, detectCharset(ct, buf));
    const out = rewriteCssUrls(css, upstream.url || target, true);
    res.writeHead(status, { ...common, 'content-type': 'text/css; charset=utf-8' });
    return res.end(out);
  }

  // Everything else: stream straight through
  res.writeHead(status, { ...common, ...(ct ? { 'content-type': ct } : {}) });
  if (!upstream.body) return res.end();
  const stream = Readable.fromWeb(upstream.body);
  stream.on('error', () => res.destroy());
  res.on('close', () => {
    try { stream.destroy(); } catch { /* ignore */ }
  });
  stream.pipe(res);
  if (process.env.RELAY_LOG !== '0') {
    console.log(`${req.method} ${target} -> ${status} ${ct.split(';')[0] || 'binary'} ${Date.now() - started}ms`);
  }
}

/* ------------------------------------------------------------------ */
/*  /api/ip  — exit node info                                          */
/* ------------------------------------------------------------------ */

let ipCache = { at: 0, data: null };

async function getExitInfo() {
  if (ipCache.data && Date.now() - ipCache.at < 5 * 60 * 1000) return ipCache.data;
  const started = Date.now();
  let ip = null;
  let geo = {};
  const results = await Promise.allSettled([
    fetch('https://ipwho.is/', { headers: { 'user-agent': UA }, signal: AbortSignal.timeout(8000) }).then((r) => r.json()),
    fetch('https://api.ipify.org?format=json', { headers: { 'user-agent': UA }, signal: AbortSignal.timeout(8000) }).then((r) => r.json()),
  ]);
  const latency = Date.now() - started;
  if (results[0].status === 'fulfilled' && results[0].value && results[0].value.success !== false) {
    geo = results[0].value;
    ip = geo.ip;
  }
  if (!ip && results[1].status === 'fulfilled' && results[1].value) ip = results[1].value.ip;
  const data = {
    ip: ip || 'unknown',
    city: geo.city || null,
    region: geo.region || null,
    country: geo.country || null,
    countryCode: geo.country_code || null,
    org: (geo.connection && geo.connection.isp) || geo.org || null,
    latencyMs: latency,
    requests: requestsServed,
  };
  ipCache = { at: Date.now(), data };
  return data;
}

/* ------------------------------------------------------------------ */
/*  Router                                                             */
/* ------------------------------------------------------------------ */

function refererTarget(req) {
  const ref = req.headers.referer;
  if (ref) {
    try {
      const ru = new URL(ref);
      const p = ru.searchParams.get('url');
      if (p) return p;
    } catch { /* fall through to the cookie */ }
  }
  // Browsers often send an origin-only Referer (or none at all) for fetch/XHR;
  // fall back to the base URL we stored when serving the last proxied page.
  const m = /(?:^|;\s*)relay_base=([^;]+)/.exec(req.headers.cookie || '');
  if (m) {
    try {
      const base = unb64url(m[1]);
      if (/^https?:\/\//.test(base)) return base;
    } catch { /* ignore */ }
  }
  return null;
}

const server = http.createServer(async (req, res) => {
  const started = Date.now();
  let pathname = '/';
  try {
    pathname = new URL(req.url, 'http://internal').pathname;
  } catch {
    return errorPage(res, 400, '', 'Bad request');
  }

  res.on('finish', () => {
    if (process.env.RELAY_LOG !== '0' && (pathname === '/' || pathname.startsWith('/api'))) {
      console.log(`${req.method} ${pathname} -> ${res.statusCode} ${Date.now() - started}ms`);
    }
  });

  try {
    if (!checkAuth(req, res)) return;

    if (pathname === '/api/config') {
      res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
      return res.end(JSON.stringify({ repoUrl: REPO_URL, auth: !!AUTH_PASS }));
    }

    // UI pages
    if (PAGE_FILES[pathname]) return servePage(res, PAGE_FILES[pathname]);

    // Static assets (theme, wallpaper, fonts)
    if (pathname.startsWith('/assets/')) return serveAsset(res, pathname);
    if (pathname === '/favicon.svg' || pathname === '/favicon.ico') {
      res.writeHead(200, { 'content-type': 'image/svg+xml', 'cache-control': 'public, max-age=86400' });
      return res.end(FAVICON);
    }
    if (pathname === '/session') {
      const nonce = sessionNonce(req);
      res.writeHead(200, {
        'content-type': 'application/json',
        'cache-control': 'no-store',
        'set-cookie': nonceSetCookie(nonce),
      });
      return res.end(JSON.stringify({ nonce }));
    }
    if (pathname === '/api/ip') {
      const data = await getExitInfo();
      data.requests = requestsServed;
      data.latencyMs = data.latencyMs;
      res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
      return res.end(JSON.stringify(data));
    }

    // Proxy a page (rewritten)
    if (pathname === '/fetch') {
      const u = new URL(req.url, 'http://internal');
      const raw = u.searchParams.get('url');
      if (!raw) return errorPage(res, 400, '', 'No URL was given to /fetch.');
      let target;
      try { target = checkTarget(raw, req); } catch (e) { return errorPage(res, 400, raw, e.message); }
      return await proxyRequest(req, res, target, { reader: u.searchParams.get('m') === '1', nonce: sessionNonce(req) });
    }

    // Proxy a raw resource (no rewriting)
    if (pathname === '/raw') {
      const u = new URL(req.url, 'http://internal');
      const raw = u.searchParams.get('url');
      if (!raw) return errorPage(res, 400, '', 'No URL was given to /raw.');
      let target;
      try { target = checkTarget(raw, req); } catch (e) { return errorPage(res, 400, raw, e.message); }
      if (req.method === 'GET' || req.method === 'HEAD') {
        // pass a browser-ish accept for assets
      }
      return await proxyRequest(req, res, target, { forceStream: true });
    }

    // Forms: /form/<base64url(target)>?fields
    if (pathname.startsWith('/form/')) {
      let target;
      try {
        target = checkTarget(unb64url(pathname.slice('/form/'.length)), req);
      } catch (e) {
        return errorPage(res, 400, '', e.message);
      }
      const t = new URL(target);
      const qi = req.url.indexOf('?');
      if (req.method === 'GET' || req.method === 'HEAD') t.search = qi >= 0 ? req.url.slice(qi) : '';
      return await proxyRequest(req, res, t.href, { nonce: sessionNonce(req) });
    }

    // Fallback: dynamic subresources requested against the proxy origin.
    // Resolve them against the origin of the page that made the request (via Referer).
    const base = refererTarget(req);
    if (base) {
      let target = null;
      try {
        target = new URL(req.url, base).href;
      } catch { /* ignore */ }
      if (target) {
        let checked;
        try { checked = checkTarget(target, req); } catch { checked = null; }
        if (checked) return await proxyRequest(req, res, checked, { nonce: sessionNonce(req) });
      }
    }

    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  } catch (err) {
    console.error('Unhandled:', err);
    if (!res.headersSent) return errorPage(res, 500, '', 'The proxy hit an unexpected error.', escapeHtml(err.message));
    try { res.destroy(); } catch { /* ignore */ }
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Relay proxy listening on http://${HOST}:${PORT}`);
});

server.on('clientError', (err, socket) => {
  try { socket.destroy(); } catch { /* ignore */ }
});

process.on('uncaughtException', (err) => console.error('uncaughtException:', err));
process.on('unhandledRejection', (err) => console.error('unhandledRejection:', err));
